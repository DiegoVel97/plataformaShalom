<?php
include_once('../model/masterModel.php');

class UsuariosModel extends MasterModel{
   
}
