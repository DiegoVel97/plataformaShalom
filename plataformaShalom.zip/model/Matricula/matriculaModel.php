<?php

include_once '../model/masterModel.php';

class matriculaModel extends MasterModel{
    //put your code here
}
