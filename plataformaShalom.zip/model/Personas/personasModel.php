<?php
include_once('../model/masterModel.php');

class personasModel extends MasterModel{
   
}