
<link href="<?php echo addLib('templates/adminMaterialize/css/materialize.css') ?>" type="text/css" rel="stylesheet" media="screen,projection">
<link href="<?php echo addLib('templates/adminMaterialize/css/style.css') ?>" type="text/css" rel="stylesheet" media="screen,projection">
<link href="<?php echo addLib('templates/adminMaterialize/css/layouts/style-fullscreen.css') ?>" type="text/css" rel="stylesheet" media="screen,projection">

<section id="content"><!-- START CONTENT -->
    <div class="container"><!--start container-->
        
        <div class="card red" id="card-alert">
            <div class="card-content white-text">
              <h4><i class="mdi-content-block" style="font-size: 30px;"></i> Alerta </h4>
              <p>
                  Actualmente no cuenta con los permisos suficientes para acceder 
                  a esta funcionalidad, por favor comunicarse con <code><b>Soporte</b></code>
              </p>
            </div>
            <button aria-label="Close" data-dismiss="alert" class="close white-text" type="button">
              <span aria-hidden="true">×</span>
            </button>
        </div>
    </div><!--end container-->
</section><!-- END CONTENT -->