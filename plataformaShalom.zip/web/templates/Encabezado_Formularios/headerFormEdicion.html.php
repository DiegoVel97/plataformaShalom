 <table class="responsive-table">
        <thead>

          <tr>
              <th><img src="<?php echo addLib('img/logo/logo_nuevo_shalom.png'); ?>" width="180px;"></th>
              <th><h4>Edici&oacute;n de Formulario</h4></th>
          </tr>
        </thead> 
</table> 
