
<br>
<div class="row">

    <div class="col s4">
        <label style="color: #448aff;"><h6>No. identificacion</h6></label> 
        <?php echo $per['per_id']; ?>
    </div>

    <div class="col s4">
        <label style="color: #448aff;"><h6>Nombre</h6></label> 
        <?php echo $per['per_nombre']; ?>
    </div>

    <div class="col s4">
        <label style="color: #448aff;"><h6>Apellido</h6></label> 
        <?php echo $per['per_apellido']; ?>
    </div>
</div>
<br>
<div class="row">

    <div class="col s4">
        <label style="color: #448aff;"><h6>Telefono</h6></label> 
        <?php echo $per['per_telefono']; ?>
    </div>

    <div class="col s4">
        <label style="color: #448aff;"><h6>Movil</h6></label> 
        <?php echo $per['per_movil']; ?>
    </div>

    <div class="col s4">
        <label style="color: #448aff;"><h6>Email</h6></label> 
        <?php echo $per['per_email']; ?>
    </div>
</div>
<br>
<div class="row">

    <div class="col s4">
        <label style="color: #448aff;"><h6>Direccion</h6></label> 
        <?php echo $per['per_direccion']; ?>
    </div>

</div>
<br>
<div class="divider"></div>

<style>
    #modalDetalle{
        top: 2% !important;
        max-height: 100%;
        height: 80%;
    }
</style>
